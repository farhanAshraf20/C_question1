/*
*Q.3
*Write a program that reverses the order of the bits in an unsigned int value. The program should
input the value from the user and call function reverseBits to print the bits in reverse order. Print the
value in bits both before and after the bits are reversed to confirm that the bits are reversed properly.
Eg:-
    Input: 8
    Output: Before:1000 A
*Date : 14-feb-2022
*Farhan Ashraf
*/

#include<stdio.h>    
#include<stdlib.h>  
int main(){  
int a[10],n,i,j,p=0;    
// printf("Enter a number : ");    
scanf("%d",&n);  

for(i=0;n>0;i++)    
    {    
        a[i]=n%2;    
        n=n/2;    
    }    
printf("Before:");    
for(i=i-1;i>=0;i--)    
    {    
        printf("%d",a[i]);
        p++;
    }
printf(" After:"); 
for(i=0;i<p;i++)    
    {    
        printf("%d",a[i]);    
    } 
return 0;  
}