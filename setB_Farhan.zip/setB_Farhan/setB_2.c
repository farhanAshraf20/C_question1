/*
Given a file containing strings separated by space, where the first string is "child" and second
string is "Father".
Write a program which finds number of grandchildren for any given string.

Example:
	file.txt
	luke shaw
	wayne rooney
	rooney ronaldo
	shaw rooney
	mike wayne

Input : ronaldo
Output:2
Date : 14-feb-2022
Farhan Ashraf
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char a[10][100],b[10][100],str[100];
void main ()
{
	FILE *fp1;
	fp1=fopen("setB_2.txt","r");
	int num=5,k;
	scanf("%s",str);

for(int i=0;i<num;i++)
{
	fscanf(fp1,"%s",a[i]);
	fscanf(fp1,"%s",b[i]);
	if(strcmp(str,b[i]) == 0)
	k = i;
}
int count = 0;
for(int i=0;i<num;i++)
{
	if(strcmp(a[k],b[i]) == 0)
	count++;
}
printf("%d\n",count);
fclose(fp1);
}
