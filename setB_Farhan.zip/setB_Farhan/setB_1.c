/*
John has a string, s consisting of n lowercase English alphabetic letters. In one operation, he can
delete any pair of adjacent letters with same value. For example, string "aabcc" would become
either "aab" or "bcc" after operation.
John wants to reduce s as much as possible. To do this, he will repeat the above operation as many
times as it can be performed. Help John out by finding and printing s non-reducible form!
Note: If the final string is empty, print "Empty String".
Input Format
The first line contains a single integer denoting the length of s.
The second line contains string s.

Constraints
    1 <= |s| <= 100
s only contains lowercase English alphabetic letters (i.e., a to z).

Output Format
If the final string is empty, print "Empty String"; otherwise, print the final non-reducible string.

Test Case - 1
    Input
    9
    aaabccddd
    Output
    abd

Explanation
John can perform the following sequence of operations to get the final string:
    aaabccddd -> abccddd
    abccddd -> abddd
    abddd -> abd
Thus, we print abd.

    Test Case - 2
    Input
    4
    baab
    Output
    Empty String

Explanation
John can perform the following sequence of operations to get the final string:
    baab -> bb
    bb -> Empty String

Thus, we print Empty String.
*Date :14-feb-2022
*Farhan Ashraf
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int i,j,k,n;
     char str[1000];
         scanf("%d",&n);
         scanf("%s",str);
         //n=strlen(str);
         for(i=0;i<n-1;i++)
         {
            if(str[i]==str[i+1])
            {
                for(j=i+2;j<n;j++)
                {
                    str[j-2]=str[j];
                }
                i=-1;n=n-2;
            }
         }
         if(n==0)
         {
             printf("Empty String");
         }
         else
         {
             for(i=0;i<n;i++)
             {
                 printf("%c",str[i]);
             }
         }


}